package com.example.android.githubsearchwithsqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.android.githubsearchwithsqlite.R;

public class SavedSearchResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_search_results);
    }
}
